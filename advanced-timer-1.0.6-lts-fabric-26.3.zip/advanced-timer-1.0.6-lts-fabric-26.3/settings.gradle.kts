pluginManagement {
	repositories {
		maven {
			name = "Fabric"
			url = uri("https://maven.fabricmc.net/")
		}
		maven {
			name = "NeoForge"
			url = uri("https://maven.neoforged.net/releases/")
		}
		mavenCentral()
		gradlePluginPortal()
		maven("https://maven.kikugie.dev/snapshots") { name = "KikuGie Snapshots" }
	}

 plugins {
		id("net.neoforged.moddev") version "2.0.141"
	}
}

plugins {
	id("dev.kikugie.stonecutter") version "0.9.1-beta.5"
}

rootProject.name = "advanced-timer"

stonecutter {
	create(rootProject) {
		version("26.3-fabric", "26.3")
	}
}
