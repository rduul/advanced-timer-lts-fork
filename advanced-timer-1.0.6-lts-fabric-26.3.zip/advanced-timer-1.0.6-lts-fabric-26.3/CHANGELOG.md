Updated Links and Icon
